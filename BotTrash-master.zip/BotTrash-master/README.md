# BotTrash
Robot recolector de basura [controlado por el Módulo ESP32](hhttps://github.com/dionej11/BotTrash-Arduino) y una aplicación movil desarrollada en Android Studio.

## Instalación
Se debe contar con el entorno de desarrollo Android Studio para posteriormente abrir el proyecto desde allí y ejecutarlo, ya sea con un emulador que la misma plataforma ofrece o con un dispositivo fisico (smartphone).

Para esta ultima se debe activar desde las configuraciones del dispositivo, el modo para desarrolladores y luego habilitar la depuración por USB.

También puede visitar: [Compilar y ejecutar tu app Android Studio](https://developer.android.com/studio/run?hl=es-419)

## Visualización de las activities o interfaces de la app

![interfaces](https://i.ibb.co/C02fwzV/Interfaces-App.png)


## Contribuciones
👩🏽‍💻 [Isabela Ceballos Franco](https://github.com/IsabelaCeballos)

👩🏽‍💻 [Daniela Jurado Blandón](https://github.com/dionej11)
